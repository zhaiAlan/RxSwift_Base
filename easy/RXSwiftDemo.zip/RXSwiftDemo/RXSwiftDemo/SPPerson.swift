//
//  SPPerson.swift
//  RXSwiftDemo
//
//  Created by zxz on 2023/6/13.
//

import Foundation

class SPPerson: NSObject {
   @objc dynamic var name:String = "Alan"
}
