//
//  ViewController.swift
//  RXSwiftDemo
//
//  Created by zxz on 2023/6/12.
//

import UIKit
import RxSwift
import RxCocoa


class ViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var textFiled: UITextField!
    var person:SPPerson = SPPerson()
    let disposeBag = DisposeBag()
    var timer: Observable<Int>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupNextwork()
//        setupTimer()
//        setupNotification()
//        setupGestureRecognizer()
//        setupScrollerView()
//        setupTextFiled()
//        setupButton()
//        setupKVO()
    }
    
    //MARK: - RxSwift应用-网络请求
    func setupNextwork() {
        
        let url = URL(string: "https://www.baidu.com")
//        传统方式
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            print("dataTask.response->" + "\(response)")
            print("dataTask.response->" + "\(data)")

        }.resume()
        
        
        URLSession.shared.rx.response(request: URLRequest(url: url!))
            .subscribe(onNext: { (response, data) in
                print("rx.response.response ==== \(response)")
                print("rx.response.data ===== \(data)")
            }, onError: { (error) in
                print("error ===== \(error)")
            }).disposed(by: disposeBag)
    }
    
    //MARK: - RxSwift应用-timer定时器
    func setupTimer() {
        timer = Observable<Int>.interval(DispatchTimeInterval.seconds(1), scheduler: MainScheduler.instance)
        timer.subscribe(onNext: { (num) in
            print("hello word \(num)")
        }).disposed(by: disposeBag)
    }

    //MARK: - 通知
    func setupNotification(){
        NotificationCenter.default.rx.notification(UIResponder.keyboardWillShowNotification)
            .subscribe(onNext: { (noti) in
                print(noti)
            })
        .disposed(by: disposeBag)
    }
    
    //MARK: - 手势
    func setupGestureRecognizer(){
        let tap = UITapGestureRecognizer()
        self.label.addGestureRecognizer(tap)
        self.label.isUserInteractionEnabled = true
        tap.rx.event.subscribe(onNext: { (tap) in
            print(tap.view)
        })
        .disposed(by: disposeBag)
    }
    
    //MARK: - RxSwift应用-scrollView
    func setupScrollerView() {
        scrollView.contentSize = CGSize(width: 300, height: 1000)
        scrollView.rx.contentOffset
            .subscribe(onNext: { [weak self](content) in
                print(content);
                print(self?.scrollView)
            })
        .disposed(by: disposeBag)
    }
    
    //MARK: - RxSwift应用-textfiled
    func setupTextFiled() {
        self.textFiled.rx.text.orEmpty
            .subscribe(onNext: { (text) in
               print(text)
            })
            .disposed(by: disposeBag)
     
        // 简单简单 更简单-RxSwift 面向开发者
        self.textFiled.rx.text
            .bind(to: self.button.rx.title())
            .disposed(by: disposeBag)

    }
    
    //MARK: - RxSwift应用-button响应
    func setupButton() {
        // 业务逻辑 和 功能逻辑
        // 设计
        self.button.rx.tap
            .subscribe(onNext: { () in
                print("按钮点击了")
            })
            .disposed(by: disposeBag)
            
    }
    
    //MARK: - RxSwift应用-KVO
    func setupKVO() {
//         self.person.addObserver(self, forKeyPath: "name", options: .new, context: nil)//传统监听
        self.person.rx.observeWeakly(String.self, "name")
            .subscribe(onNext: { (value) in
                print(value as Any)
            })
            .disposed(by: disposeBag)
    }
//    传统监听需要方法
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        print("响应")
        print(change as Any)
    }
//    传统监听需要逻辑
    deinit {
        self.removeObserver(self.person, forKeyPath: "name", context: nil)
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        textFiled.resignFirstResponder()
        print("来了")
        person.name = "\(person.name) +"
         print(person.name)
    }
    
    @objc func didClickButton(){
        print("点了,天王盖地虎")
    }

    
}

//extension ViewController: UITextFieldDelegate{
//
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        if let num = Int(string) {
//            if num % 2 == 1 {
//                print("打印输入的奇数:\(num)")
//            }
//        }
//        return true
//    }
//}


