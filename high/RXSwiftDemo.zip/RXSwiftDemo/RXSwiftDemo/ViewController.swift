//
//  ViewController.swift
//  RXSwiftDemo
//
//  Created by zxz on 2023/6/12.
//

import UIKit
import RxSwift
import RxCocoa

struct SPPlayer {
    var score: BehaviorRelay<Int>
}


class ViewController: UIViewController {
    var disposeBag = DisposeBag()
    let spError = SPError.A
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        flatMap()
        flatMapLatest()
        elementAt()
        single()
        take()
        takeLast()
        takeWhile()
        takeUntil()
        skip()
        skipUntil()
        toArray()
        reduce()
        concat()
        catchAndReturn()
        catchSequence()
        retry()
        retry1()
        debug()
        testMulticastConnectOperators()
        testReplay()
    }
    func testReplay(){
        print("*****replay*****")

        let intSequence = Observable<Int>.interval(.seconds(1), scheduler: MainScheduler.instance)
            .replay(5)

        _ = intSequence
            .subscribe(onNext: { print(Date(),"订阅 1:, Event: \($0)") })

        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            _ = intSequence.connect()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
          _ = intSequence
              .subscribe(onNext: { print(Date(),"订阅 2:, Event: \($0)") })
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
          _ = intSequence
              .subscribe(onNext: { print(Date(),"订阅 3:, Event: \($0)") })
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
            self.disposeBag = DisposeBag()
        }

    }


    func testMulticastConnectOperators(){
        print("*****multicast*****")
        let netOB = Observable<Any>.create { (observer) -> Disposable in
                sleep(2)// 模拟网络延迟
                print("我开始请求网络了")
                observer.onNext("请求到的网络数据")
                observer.onNext("请求到的本地")
                observer.onCompleted()
                return Disposables.create {
                    print("销毁回调了")
                }
            }.publish()
        
        netOB.subscribe(onNext: { (anything) in
                print("订阅1:",anything)
            })
            .disposed(by: disposeBag)

        // 我们有时候不止一次网络订阅,因为有时候我们的数据可能用在不同的额地方
        // 所以在订阅一次 会出现什么问题?
        netOB.subscribe(onNext: { (anything) in
                print("订阅2:",anything)
            })
            .disposed(by: disposeBag)
        
        _ = netOB.connect()
        /**
            输出结果为：
         *****multicast*****
         我开始请求网络了
         订阅1: 请求到的网络数据
         订阅2: 请求到的网络数据
         订阅1: 请求到的本地
         订阅2: 请求到的本地
         销毁回调了

         **/
    }
    
    func debug(){
        print("*****debug*****")
        var count = 1

        let sequenceThatErrors = Observable<String>.create { observer in
            observer.onNext("alan")
            observer.onNext("zhai")
            observer.onNext("qiang")
            
            if count < 5 {
                observer.onError(self.spError)
                print("错误序列来了")
                count += 1
            }
            
            observer.onNext("liLei")
            observer.onNext("yanzi")
            observer.onNext("zhuang")
            observer.onCompleted()
            
            return Disposables.create()
        }

        sequenceThatErrors
            .retry(3)
            .debug()
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)

    }
    func retry1(){
        print("*****retry(_:)*****")
        var count = 1
        let sequenceThatErrors = Observable<String>.create { observer in
            observer.onNext("alan")
            observer.onNext("xing")
            observer.onNext("qiangqiang")
            
            if count < 5 { // 这里设置的错误出口是没有太多意义的额,因为我们设置重试次数
                observer.onError(self.spError)
                print("错误序列来了")
                count += 1
            }
            
            observer.onNext("liLei")
            observer.onNext("yanzi")
            observer.onNext("ting")
            observer.onCompleted()
            
            return Disposables.create()
        }

        sequenceThatErrors
            .retry(3)
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
    }
    func retry(){
        print("*****retry*****")
        var count = 1 // 外界变量控制流程
        let sequenceRetryErrors = Observable<String>.create { observer in
            observer.onNext("alan")
            observer.onNext("xing")
            observer.onNext("zhai")
            
            if count == 1 {
                // 流程进来之后就会过度-这里的条件可以作为出口,失败的次数
                observer.onError(self.spError)  // 接收到了错误序列,重试序列发生
                print("错误序列来了")
                count += 1
            }
            
            observer.onNext("liLie")
            observer.onNext("yanzi")
            observer.onNext("ting")
            observer.onCompleted()
            
            return Disposables.create()
        }

        sequenceRetryErrors
            .retry()
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        
        /***
        输出结果：
         *****retry*****
         alan
         xing
         zhai
         错误序列来了
         alan
         xing
         zhai
         liLie
         yanzi
         ting

         */
    }
    
    func catchSequence(){
        print("*****catch*****")
        let sequenceThatFails = PublishSubject<String>()
        let recoverySequence = PublishSubject<String>()

        sequenceThatFails
            .catch {
                print("Error:", $0)
                return recoverySequence
            }
            .subscribe { print($0) }
            .disposed(by: disposeBag)

        sequenceThatFails.onNext("😬")
        sequenceThatFails.onNext("😨")
        sequenceThatFails.onNext("😡")
        sequenceThatFails.onNext("🔴")
        sequenceThatFails.onError(self.spError)
        recoverySequence.onNext("😊")
    }
    
    func catchAndReturn(){
        print("*****catchAndReturn*****")
        let sequenceThatFails = PublishSubject<String>()

        sequenceThatFails
            .catchAndReturn("alan")
            .subscribe (onNext: { print($0) })
            .disposed(by: disposeBag)

        sequenceThatFails.onNext("qiang")
        sequenceThatFails.onNext("lilei") // 正常序列发送成功的
        //发送失败的序列,一旦订阅到位 返回我们之前设定的错误的预案
        sequenceThatFails.onError(self.spError)
    }
    func concat(){
        print("*****concat*****")
        let subject1 = BehaviorSubject(value: "zhai")
        let subject2 = BehaviorSubject(value: "1")

        let subjectsSubject = BehaviorSubject(value: subject1)

        subjectsSubject.asObservable()
            .concat()
            .subscribe (onNext:{ print($0) })
            .disposed(by: disposeBag)

        subject1.onNext("alan")
        subject1.onNext("xing")

        subjectsSubject.onNext(subject2)

        subject2.onNext("打印不出来")
        subject2.onNext("2")

        subject1.onCompleted() // 必须要等subject1 完成了才能订阅到! 用来控制顺序 网络数据的异步
        subject2.onNext("3")
    }
    func reduce(){
        print("*****reduce*****")
        Observable.of(10, 100, 1000)
            .reduce(1, accumulator: +) // 1 + 10 + 100 + 1000 = 1111
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        //        输出结果：1111
    }
    func toArray(){
        print("*****toArray*****")
        Observable.range(start: 1, count: 10)
            .toArray()
            .subscribe(onSuccess: { print($0) })
            .disposed(by: disposeBag)
//        输出结果：[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    }
    func skipUntil(){
        print("*****skipUntil*****")
        let sourceSeq = PublishSubject<String>()
        let referenceSeq = PublishSubject<String>()

        sourceSeq
            .skip(until: referenceSeq)
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)

        // 没有条件命令 下面走不了
        sourceSeq.onNext("alan")
        sourceSeq.onNext("zhai")
        sourceSeq.onNext("qiang")

        referenceSeq.onNext("zhuang") // 条件一出来,下面就可以走了

        sourceSeq.onNext("lilei")
        sourceSeq.onNext("yanzi")
        sourceSeq.onNext("meimei")
    }
    func skip(){
        print("*****skip*****")
        Observable.of(1, 2, 3, 4, 5, 6)
            .skip(2)
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        
        print("*****skipWhile*****")
        Observable.of(1, 2, 3, 4, 5, 6)
            .skip(while :{int in
                int < 3
            })
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
    }
    func takeUntil(){
        print("*****takeUntil*****")
        let sourceSequence = PublishSubject<String>()
        let referenceSequence = PublishSubject<String>()

        sourceSequence
            .take(until: referenceSequence)
            .subscribe (onNext:{ print($0) })
            .disposed(by: disposeBag)

        sourceSequence.onNext("alan")
        sourceSequence.onNext("zhai")
        sourceSequence.onNext("xing")

        referenceSequence.onNext("zhuang") // 条件一出来,下面就走不了

        sourceSequence.onNext("qiang")
        sourceSequence.onNext("yanzi")
        sourceSequence.onNext("ting")
    }
    func takeWhile(){
        print("*****takeWhile*****")
        Observable.of(1, 2, 3, 4, 5, 6)
            .take(while: { int in
                int < 3
            })
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        //        输出结果 1,2
    }
    func takeLast(){
        print("*****takeLast*****")
        Observable.of("alan", "zhuang","xing", "zhai")
            .takeLast(3)
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        //输出结果：zhuang xing zhai
    }
    func take(){
        print("*****take*****")
        Observable.of("alan", "zhuang","xing", "zhai")
            .take(2)
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        //输出 alan zhuang
    }
    func single(){
        print("*****single*****")
        Observable.of("alan", "zhi")
            .single()
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)

        Observable.of("zhai", "zhuang")
            .single { $0 == "zhuang" }
            .subscribe (onNext:{ print($0,"---single---") })
            .disposed(by: disposeBag)
        /**
         输出结果：
         alan
         Unhandled error happened: Sequence contains more than one element.
         zhuang ---single---
         **/
    }
    func elementAt(){
        print("*****elementAt*****")
        Observable.of("A", "l", "a", "n", "z")
            .element(at: 3)
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
    }
    func distinctUntilChanged(){
        print("*****distinctUntilChanged*****")
        Observable.of("1", "2", "2", "2", "3", "3", "4")
            .distinctUntilChanged()
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
    }
    func filter(){
        print("*****filter*****")
        Observable.of(1,2,3,4,5,6,7,8,9,0)
            .filter { $0 % 2 == 0 }
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
    }
    func scan(){
        print("*****scan*****")
        Observable.of(10, 100, 1000)
            .scan(2) { aggregateValue, newValue in
                aggregateValue + newValue // 10 + 2 , 100 + 10 + 2 , 1000 + 100 + 2
            }
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        // 这里主要强调序列值之间的关系
    }
    
    func flatMapLatest(){
        print("*****flatMapLatest*****")
        
        let boy  = SPPlayer(score: BehaviorRelay(value: 100))
        let girl = SPPlayer(score: BehaviorRelay(value: 90))
        let player = BehaviorSubject(value: boy)
        player.asObservable()
            .flatMapLatest{$0.score.asObservable() } // 本身score就是序列 模型就是序列中的序列
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        boy.score.accept(75)
        player.onNext(girl)
        boy.score.accept(50)
        boy.score.accept(40)//  如果切换到 flatMapLatest 就不会打印
        girl.score.accept(10)
        girl.score.accept(0)
        //        输出结果为：100,75,90,10,0

    }
    func flatMap(){
        print("*****flatMap*****")
        let boy  = SPPlayer(score: BehaviorRelay(value: 100))
        let girl = SPPlayer(score: BehaviorRelay(value: 90))
        let player = BehaviorSubject(value: boy)
        player.asObservable()
            .flatMap {$0.score.asObservable() } // 本身score就是序列 模型就是序列中的序列
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        boy.score.accept(75)
        player.onNext(girl)
        boy.score.accept(50)
        boy.score.accept(40)//  如果切换到 flatMapLatest 就不会打印
        girl.score.accept(10)
        girl.score.accept(0)
        
        //        输出结果为：100,75,90,50,40,10,0
    }
    
    func map(){
        print("*****map*****")
        let ob = Observable.of(1,2,3,4)
        ob.map { (number) -> Int in
            return number+2
            }
            .subscribe{
                print("\($0)")
            }
            .disposed(by: disposeBag)
    }
    
    
    func switchLatest(){
        print("*****switchLatest*****")
        let switchLatestSub1 = BehaviorSubject(value: "L")
        let switchLatestSub2 = BehaviorSubject(value: "1")
        let switchLatestSub  = BehaviorSubject(value: switchLatestSub1)// 选择了 switchLatestSub1 就不会监听 switchLatestSub2

        switchLatestSub.asObservable()
            .switchLatest()
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)

        switchLatestSub1.onNext("G")
        switchLatestSub1.onNext("_")
        switchLatestSub2.onNext("2")
        switchLatestSub2.onNext("3") // 2-3都会不会监听,但是默认保存由 2覆盖1 3覆盖2
        switchLatestSub.onNext(switchLatestSub2) // 切换到 switchLatestSub2
        switchLatestSub1.onNext("*")
        switchLatestSub1.onNext("alan") // 原理同上面 下面如果再次切换到 switchLatestSub1会打印出 alan
        switchLatestSub2.onNext("4")
    }
    
    func combineLatest(){
        print("*****combineLatest*****")
        let stringSub = PublishSubject<String>()
        let intSub = PublishSubject<Int>()
        Observable.combineLatest(stringSub, intSub) { strElement, intElement in
                "\(strElement) \(intElement)"
            }
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)

        stringSub.onNext("S") // 存一个 S
        stringSub.onNext("P") // 存了一个覆盖 - 和zip不一样
        intSub.onNext(1)      // 发现strOB也有G 响应 G 1
        intSub.onNext(2)      // 覆盖1 -> 2 发现strOB 有值G 响应 G 2
        stringSub.onNext("alan") // 覆盖G -> alan 发现intOB 有值2 响应 alan 2
        // combineLatest 比较zip 会覆盖
        // 应用非常频繁: 比如账户和密码同时满足->才能登陆. 不关系账户密码怎么变化的只要查看最后有值就可以 loginEnable
    }
    func zip(){
        print("*****zip*****")
        let stringSubject = PublishSubject<String>()
        let intSubject = PublishSubject<Int>()

        Observable.zip(stringSubject, intSubject) { stringElement, intElement in
                "\(stringElement) \(intElement)"
            }
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)

        stringSubject.onNext("C")
        stringSubject.onNext("o") // 到这里存储了 C o 但是不会响应除非;另一个响应

        intSubject.onNext(1) // 勾出一个
        intSubject.onNext(2) // 勾出另一个
        stringSubject.onNext("i") // 存一个
        intSubject.onNext(3) // 勾出一个
        // 说白了: 只有两个序列同时有值的时候才会响应,否则存值
    }
    
    func merge(){
        print("*****merge*****")
        let subject1 = PublishSubject<String>()
        let subject2 = PublishSubject<String>()
        // merge subject1和subject2
        Observable.of(subject1, subject2)
            .merge()
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)

        subject1.onNext("C")
        subject1.onNext("o")
        subject2.onNext("o")
        subject2.onNext("o")
        subject1.onNext("c")
        subject2.onNext("i")
    }
    func startWith() -> Void {
        print("*****startWith*****")
        Observable.of("1", "2", "3", "4")
            .startWith("A")
            .startWith("B")
            .startWith("C", "a", "b")
            .subscribe(onNext: { print($0) })
            .disposed(by: disposeBag)
        //效果: CabBA1234
    }
    enum SPError:Error {
        case A
        case B
        var errorType:String {
            switch self {
            case .A:
                return "i am error A"
            case .B:
                return "BBBB"
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
    



