//
//  ViewController.swift
//  RXSwiftDemo
//
//  Created by zxz on 2023/6/12.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {
    let disposeB = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        testdispose();
//        testCombineLatest()
//        testZipWith()
        filter_map_reduce()
        
    }
    func filter_map_reduce() -> Void {
        Observable<Int>.from([1, 2, 3, 4, 5])
            .filter { $0 > 3 }
            .subscribe(onNext: { element in
                print("element:", element)
            })
            .disposed(by: disposeB)
        
        
        print("-------",Date())
        Observable<Int>.from([1, 2, 3, 4, 5])
            .map { $0 + 10 }
            .subscribe(onNext: { element in
                print("element:", element)
            })
            .disposed(by: disposeB)
        
        
        print("-------",Date())
        Observable<Int>.from([1, 2, 3, 4, 5])
            .reduce(0, accumulator: { $0 + $1 })
            .subscribe(onNext: { element in
                print("element:", element)
            })
            .disposed(by: disposeB)
        
        print("-------",Date())
    }
    func testZipWith() -> Void {
        print("zipSigal",Date())

        let zipSignalA = Observable<Any>.create { (observ) -> Disposable in
            observ.onNext("alan1")
            observ.onNext("alan2")
            observ.onCompleted()
            return Disposables.create()
        }
        let zipSignalB = Observable<Any>.create { (observ) -> Disposable in
            DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute:{
                observ.onNext("alan3")
            })
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 5, execute:{
                observ.onNext("alan4")
                observ.onCompleted()
            })
            return Disposables.create()
        }
        let zipSigal = Observable<Any>.zip(zipSignalA, zipSignalB)
        
        zipSigal.subscribe { (even) in
            print("zipSigal" + "\(even)",Date())
        }.disposed(by: disposeB)//销毁
    }
    func testCombineLatest() -> Void {
        
        let combineSignalA = Observable<Any>.create { (observ) -> Disposable in
            observ.onNext("alan1")
            observ.onNext("alan2")
            observ.onCompleted()
            return Disposables.create()
        }
        let combineSignalB = Observable<Any>.create { (observ) -> Disposable in
            observ.onNext("alan3")
            observ.onNext("alan4")
            observ.onCompleted()
            return Disposables.create()
        }
        let combineSignal = Observable<Any>.combineLatest(combineSignalA, combineSignalB);
        
        combineSignal.subscribe { (even) in
            print("combineSignal" + "\(even)")
        }.disposed(by: disposeB)//销毁
        
    }
    
    func testdispose() -> Void {
        
        //通过指定的方法实现来自定义一个被观察的序列。
        //订阅创建
        let myOb = Observable<Any>.create { (observ) -> Disposable in
            observ.onNext("alan")
            observ.onCompleted()
            return Disposables.create()
        }
        //订阅事件
        myOb.subscribe { (even) in
            print("subscribe" + "\(even)")
        }.disposed(by: disposeB)//销毁

        //各种观察者序列产生方式
        
        //该方法通过传入一个默认值来初始化。
        Observable.just("just")
            .subscribe { (event) in
                print(event)
            }
            .disposed(by: disposeB)
        
        //该方法可以接受可变数量的参数（必需要是同类型的）
        Observable.of("o","f","of").subscribe { (event) in
            print(event)
        }.disposed(by: disposeB)

        //该方法需要一个数组参数。
        Observable.from(["f","r","o","m"]).subscribe { (event) in
            print("from" + "\(event)")
        }.disposed(by: disposeB)

        //该方法创建一个永远不会发出 Event（也不会终止）的 Observable 序列。
        Observable<Int>.never().subscribe { (event) in
            print(event)
        }.disposed(by: disposeB)

//       // 该方法创建一个空内容的 Observable 序列。 //会打印complete
        Observable<Int>.empty().subscribe { (event) in
            print("empty" ,event)
        }.disposed(by: disposeB)

        //该方法创建一个不做任何操作，而是直接发送一个错误的 Observable 序列。
        let myError = MyError.A
        print(myError.errorType)
        Observable<Int>.error(myError).subscribe { (event) in
            print(event.error)
        }.disposed(by: disposeB)

        //该方法通过指定起始和结束数值，创建一个以这个范围内所有值作为初始值的Observable序列。
        Observable.range(start: 1, count: 6).subscribe { (event) in
            print(event)
        }.disposed(by: disposeB)

        //该方法创建一个可以无限发出给定元素的 Event的 Observable 序列（永不终止）。慎重使用
//        Observable.repeatElement("SPAlan").subscribe { (event) in
//            print(event)
//        }.disposed(by: disposeB)

        //该方法创建一个只有当提供的所有的判断条件都为 true 的时候，才会给出动作的 Observable 序列。
        //第一个参数:初始化的数值  第二个 条件  第三也是一个条件 0 + 2 <= 10 依次循环下去,iterate:重复执行 ，执行结果为 0,2,4,6,8,10
        Observable.generate(initialState: 0, condition: {$0<=10}, iterate: {$0+2}).subscribe { (event) in
            print(event)
            }.disposed(by: disposeB)

        //上面和下面的效果一样
        Observable.of(0,2,4,6,8,10).subscribe { (event) in
            print(event)
        }.disposed(by: disposeB)

        //该个方法相当于是创建一个 Observable 工厂，通过传入一个 block 来执行延迟 Observable序列创建的行为，而这个 block 里就是真正的实例化序列对象的地方。
        var isOdd = true
        let factory: Observable<Int> = Observable.deferred { () -> Observable<Int> in

            isOdd = !isOdd
            if isOdd{
                return Observable.of(0,2,4,6,8)
            }else{
                return Observable.of(1,3,5,7,9)
            }
        }
        //这里会调用上面的工厂
        factory.subscribe { (event) in
            print("\(isOdd)",event)
        }.disposed(by: disposeB)
        //这里会再次调用工厂
        factory.subscribe { (event) in
            print("\(isOdd)",event)
        }.disposed(by: disposeB)
        
        
        //这个方法创建的 Observable 序列每隔一段设定的时间，会发出一个索引数的元素。而且它会一直发送下去。
//        Observable<Int>.interval(DispatchTimeInterval.seconds(1), scheduler: MainScheduler.instance).subscribe { (event) in
//            print(event)
//        }.disposed(by: disposeB)
        
        //这个方法有两种用法，一种是创建的 Observable序列在经过设定的一段时间后，产生唯一的一个元素。，这个只调用一次
        Observable<Int>.timer(DispatchTimeInterval.seconds(1), scheduler: MainScheduler.instance).subscribe{(event) in
            print("123",event)
        }.disposed(by: disposeB)

        //另一种是创建的 Observable 序列在经过设定的一段时间后，每隔一段时间产生一个元素。:经过5秒后每个1秒创建一个元素
//        Observable<Int>.timer(DispatchTimeInterval.seconds(5), period: DispatchTimeInterval.seconds(1), scheduler: MainScheduler.instance).subscribe { (event) in
//            print(event)
//        }.disposed(by: disposeB)
    }
    
    enum MyError:Error {
        case A
        case B
        var errorType:String {
            switch self {
            case .A:
                return "i am error A"
            case .B:
                return "BBBB"
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


